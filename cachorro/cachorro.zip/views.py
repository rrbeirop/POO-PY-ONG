
def menu():
     return "1- CRIAR CÃO \n2- CRIAR HUMANO:\n3- LISTAR CACHORRO: \n4- LISTAR HUMANO:"

# def menu_dog():
#        print ("rsrsrs")
#        return "1- CACHORRAO "

# def human():
#       return "2- LISTAR HUMAN"
     
